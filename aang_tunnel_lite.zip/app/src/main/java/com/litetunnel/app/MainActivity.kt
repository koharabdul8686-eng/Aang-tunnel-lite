package com.litetunnel.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var prefs: SharedPreferences
    private lateinit var etTarget: EditText
    private lateinit var etProxy: EditText
    private lateinit var etPayload: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundRect(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun iconButton(res: Int, desc: String, onClick: (View) -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.contentDescription = desc
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setOnClickListener { v -> onClick(v) }
        return b
    }

    private fun field(hintText: String, value: String, multi: Boolean): EditText {
        val et = EditText(this)
        et.hint = hintText
        et.setText(value)
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.parseColor("#9E9E9E"))
        et.textSize = 14f
        var type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (multi) {
            type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            et.maxLines = 4
        } else {
            et.setSingleLine(true)
        }
        et.inputType = type
        et.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#4A4A4A"))
        return et
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#151515"))
        }

        // ---- app bar: judul + hati + tempat sampah + menu titik tiga ----
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#2B2B2B"))
            setPadding(dp(16), 0, dp(4), 0)
        }
        bar.addView(TextView(this).apply {
            text = "AANG TUNNEL LITE"
            textSize = 20f
            setTextColor(Color.parseColor("#EEEEEE"))
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(iconButton(R.drawable.ic_heart, "Simpan") {
            saveFields()
            Toast.makeText(this, "Pengaturan tersimpan", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(48), dp(56)))
        bar.addView(iconButton(R.drawable.ic_delete, "Hapus log") {
            AppLog.clear()
            logView.text = ""
        }, LinearLayout.LayoutParams(dp(48), dp(56)))
        bar.addView(iconButton(R.drawable.ic_more, "Menu") { anchor -> showMenu(anchor) },
            LinearLayout.LayoutParams(dp(48), dp(56)))
        page.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        // ---- isi ----
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(40), dp(12), dp(12))
        }
        scroll = ScrollView(this).apply { addView(body) }
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // kartu: SSH (atas) -> proxy (tengah) -> payload (bawah)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(Color.parseColor("#2A2A2A"), 4)
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }
        card.addView(TextView(this).apply {
            text = "SSH  \u2022  Performance Mode  \u2022  Proxy -> Target"
            textSize = 14f
            setTextColor(Color.parseColor("#EEEEEE"))
        })
        etTarget = field("target", prefs.getString("target", "") ?: "", false)
        etProxy = field("proxy", prefs.getString("proxy", "") ?: "", false)
        etPayload = field("payload", prefs.getString("payload", DEFAULT_PAYLOAD) ?: DEFAULT_PAYLOAD, true)
        val fp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        card.addView(etTarget, fp)
        card.addView(etProxy, fp)
        card.addView(etPayload, fp)
        body.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        btn = Button(this).apply {
            text = "CONNECT"
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            textSize = 16f
            letterSpacing = 0.1f
            background = roundRect(Color.parseColor("#B388FF"), 4)
            stateListAnimator = null
        }
        body.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(12) })

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 14f
            setTextColor(Color.parseColor("#DDDDDD"))
            setPadding(dp(2), dp(12), 0, 0)
        }
        body.addView(logView)

        btn.setOnClickListener {
            if (State.running) {
                startService(Intent(this, TunnelService::class.java).setAction(TunnelService.ACTION_STOP))
            } else {
                saveFields()
                AppLog.clear()
                logView.text = ""
                if (loadCfg(prefs) == null) {
                    AppLog.add("Error: format target salah. Pakai host:port@user:pass")
                } else {
                    val i = Intent(this, TunnelService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                }
            }
        }

        if (AppLog.lines.isEmpty()) {
            AppLog.add("Running on ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} API ${Build.VERSION.SDK_INT}. Version ${versionName()}.")
        }
        setContentView(page)
    }

    private fun versionName(): String =
        try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun saveFields() {
        prefs.edit()
            .putString("target", etTarget.text.toString().trim())
            .putString("proxy", etProxy.text.toString().trim())
            .putString("payload", etPayload.text.toString().trim())
            .apply()
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val port = prefs.getString("socks_port", "1080") ?: "1080"
        pm.menu.add(0, 1, 0, "Port SOCKS5 lokal ($port)")
        pm.menu.add(0, 2, 1, "Bantuan format")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> askSocksPort()
                2 -> AlertDialog.Builder(this)
                    .setTitle("Bantuan format")
                    .setMessage(
                        "target : host:port@user:password\n" +
                        "         contoh: 1.2.3.4:22@user:pass\n\n" +
                        "proxy : host:port (kosongkan jika tanpa proxy)\n\n" +
                        "payload : pakai [crlf], [host], [port], [host_port], [ua]\n\n" +
                        "Setelah CONNECT, arahkan aplikasi lain ke SOCKS5 127.0.0.1:$port"
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun askSocksPort() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText(prefs.getString("socks_port", "1080"))
        AlertDialog.Builder(this)
            .setTitle("Port SOCKS5 lokal")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().trim().toIntOrNull()
                if (v != null && v in 1024..65535) {
                    prefs.edit().putString("socks_port", v.toString()).apply()
                } else {
                    Toast.makeText(this, "Port harus 1024-65535", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        synchronized(AppLog) {
            logView.text = AppLog.lines.joinToString("\n")
        }
        AppLog.listener = { line ->
            runOnUiThread {
                logView.append(if (logView.text.isEmpty()) line else "\n$line")
                scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
        State.onChange = { runOnUiThread { refreshButton() } }
        refreshButton()
    }

    override fun onPause() {
        AppLog.listener = null
        State.onChange = null
        super.onPause()
    }

    private fun refreshButton() {
        btn.text = if (State.running) "DISCONNECT" else "CONNECT"
    }
}
