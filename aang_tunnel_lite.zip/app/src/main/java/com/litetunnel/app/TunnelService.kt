package com.litetunnel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class TunnelService : Service() {
    private var tunnel: Tunnel? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            tunnel?.stop()
            tunnel = null
            releaseWake()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(1, buildNotification())

        if (tunnel != null && !State.running) {
            tunnel?.stop()
            tunnel = null
        }

        if (tunnel == null) {
            val cfg = loadCfg(getSharedPreferences("cfg", MODE_PRIVATE))
            if (cfg == null) {
                AppLog.add("Error: format target salah. Pakai host:port@user:pass")
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            if (wake == null) {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aang:tunnel").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
            AppLog.add("Running on ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} API ${Build.VERSION.SDK_INT}")
            tunnel = Tunnel(cfg).also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun releaseWake() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) {}
        wake = null
    }

    override fun onDestroy() {
        tunnel?.stop()
        releaseWake()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("tunnel", "Tunnel", NotificationManager.IMPORTANCE_LOW)
            )
            b = Notification.Builder(this, "tunnel")
        } else {
            b = Notification.Builder(this)
        }
        return b.setContentTitle("AANG TUNNEL LITE")
            .setContentText("Tunnel aktif - SOCKS5 127.0.0.1")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.litetunnel.app.STOP"
    }
}
